using Revit2025AIMan.Commands;
using Revit2025AIMan.Core;
using System;
using System.Collections.Generic;

namespace Revit2025AIMan.NLP
{
    public class OpenAiNlpProvider : INlpProvider
    {
        public Intent GetIntent(string text) => throw new NotImplementedException();

        // --- Names & counts ---
        public string ExtractName(string text) => throw new NotImplementedException();
        public List<string> ExtractNamesList(string text) => throw new NotImplementedException();
        public int? ExtractCount(string text) => throw new NotImplementedException();

        // --- View/Sheet/Level ---
        public string ExtractViewType(string text) => throw new NotImplementedException();
        public string ExtractSheetSubtype(string text) => throw new NotImplementedException();
        public string ExtractLevel(string text) => throw new NotImplementedException();
        public List<string> ExtractLevelsList(string text) => throw new NotImplementedException();
        public (List<string> levelNumbers, List<string> elevations) ExtractLevelsForCreate(string text) => throw new NotImplementedException();

        // --- Sheet naming ---
        public (string number, string title) ParseSheetNumberAndTitle(string text) => throw new NotImplementedException();

        // --- Rename ---
        public string ExtractOldName(string text) => throw new NotImplementedException();
        public string ExtractNewName(string text) => throw new NotImplementedException();

        // --- Export ---
        public ExportType? ExtractExportType(string text) => throw new NotImplementedException();

        // --- Parameters ---
        public string GetParameterName(string text) => throw new NotImplementedException();
        public (string elementName, string paramName, string newValue) ExtractParameterChange(string text) => throw new NotImplementedException();
        public string ExtractValue(string text) => throw new NotImplementedException();

        // --- Duplicate ---
        public (string mode, string newName) ExtractDuplicateOptions(string text) => throw new NotImplementedException();

        // --- Category ---
        public string ExtractCategory(string text) => throw new NotImplementedException();
    }
}
