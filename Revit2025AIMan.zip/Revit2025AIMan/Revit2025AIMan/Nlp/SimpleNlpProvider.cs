﻿using Revit2025AIMan.Commands;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using Revit2025AIMan.Core;

namespace Revit2025AIMan.NLP
{
    public class SimpleNlpProvider : INlpProvider
    {
        // -------------------
        // Intent detection
        // -------------------
        public Intent GetIntent(string text)
        {
            var lowerText = text?.ToLower() ?? string.Empty;

            // create synonyms
            if (Regex.IsMatch(lowerText, @"\b(create|make|add|generate|new|duplicate|dup)\b"))
            {
                // If text explicitly says duplicate, prefer DuplicateView
                if (Regex.IsMatch(lowerText, @"\b(duplicate|dup)\b")) return Intent.DuplicateView;
                return Intent.Create;
            }

            if (Regex.IsMatch(lowerText, @"\b(rename|change\s+name|renaming)\b")) return Intent.Rename;

            if (Regex.IsMatch(lowerText, @"\b(list|show|properties|describe)\b")) return Intent.ListProperties;

            if (Regex.IsMatch(lowerText, @"\b(export|print|save)\b")) return Intent.Export;

            if (Regex.IsMatch(lowerText, @"\b(change|set|update)\b") && Regex.IsMatch(lowerText, @"\b(material|mark|keynote|comment|comments|name)\b"))
                return Intent.ChangeParameter;

            if (Regex.IsMatch(lowerText, @"\b(reload|refresh)\b")) return Intent.ReloadLink;

            if (Regex.IsMatch(lowerText, @"\b(duplicate|dup|copy)\b")) return Intent.DuplicateView;

            return Intent.Unknown;
        }

        // -------------------
        // Basic single-name extraction (preserve case)
        // -------------------
        public string ExtractName(string text)
        {
            if (string.IsNullOrWhiteSpace(text)) return string.Empty;

            // 1) Quoted string -> "Hardscape Plan"
            var quoted = Regex.Match(text, @"[""'](.+?)[""']");
            if (quoted.Success) return quoted.Groups[1].Value.Trim();

            // 2) 'named X' or 'name X' or 'called X' capturing until known delimiters
            var named = Regex.Match(text, @"\b(?:named|name|called|titled)\s+(.+?)(?=(?:\s+(?:on|at|in|under|for|as|with|respectively|,|$)))", RegexOptions.IgnoreCase);
            if (named.Success) return named.Groups[1].Value.Trim();

            // 3) After create <type> ... capture trailing phrase until preposition or end
            var fallback = Regex.Match(text, @"\b(?:create|make|new|add|duplicate)\b.*?(?:named\s+)?(.+?)(?=(?:\s+(?:on|at|in|under|for|with|respectively|,|as|$)))", RegexOptions.IgnoreCase);
            if (fallback.Success) return fallback.Groups[1].Value.Trim();

            // 4) Last 2 words as fallback
            var words = text.Trim().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            if (words.Length >= 2)
                return words[words.Length - 2] + " " + words[words.Length - 1];

            return words.LastOrDefault() ?? string.Empty;
        }

        // -------------------
        // Extract multiple comma-separated names (handles "respectively")
        // Example: "create 3 sheets named A302-Rock Plan, A303-Furniture Plan, A501-Electrical Plan respectively"
        // Returns list of trimmed names.
        // -------------------
        public List<string> ExtractNamesList(string text)
        {
            var list = new List<string>();
            if (string.IsNullOrWhiteSpace(text)) return list;

            // If quoted group of names: "A302-Rock Plan", "A303-Furniture Plan"
            var quotedMatches = Regex.Matches(text, @"[""'](.+?)[""']");
            if (quotedMatches.Count > 1)
            {
                foreach (Match m in quotedMatches) list.Add(m.Groups[1].Value.Trim());
                return list;
            }

            // After 'named' capture everything after it up to optionally 'respectively' or end
            var named = Regex.Match(text, @"\bnamed\s+(.+?)(?:\s+respectively)?$", RegexOptions.IgnoreCase);
            string raw = string.Empty;
            if (named.Success) raw = named.Groups[1].Value;
            else
            {
                // try "name it" or "and name it"
                var nameIt = Regex.Match(text, @"\bname(?:d)?\s*(?:it\s*)?(?:is\s*)?(.+?)(?:\s+respectively)?$", RegexOptions.IgnoreCase);
                if (nameIt.Success) raw = nameIt.Groups[1].Value;
            }

            if (!string.IsNullOrWhiteSpace(raw))
            {
                // split by comma or " , " and trim
                var parts = raw.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries).Select(p => p.Trim()).Where(p => p.Length > 0).ToList();
                if (parts.Any()) return parts;
            }

            // fallback: try to capture comma-separated tokens in the whole sentence
            var catchAllParts = Regex.Split(text, @"\s*,\s*").Select(p => p.Trim()).Where(p => p.Length > 0).ToList();
            // Heuristic: return if plausible multiple names (>=2 and at least one contains non-numeric)
            if (catchAllParts.Count >= 2 && catchAllParts.Any(p => Regex.IsMatch(p, @"[A-Za-z]"))) return catchAllParts;

            // Single fallback: return single extracted name (if any)
            var single = ExtractName(text);
            if (!string.IsNullOrEmpty(single)) list.Add(single);

            return list;
        }

        // -------------------
        // Extract count "create 3 views" or "make 2 sheets"
        // -------------------
        public int? ExtractCount(string text)
        {
            if (string.IsNullOrWhiteSpace(text)) return null;

            // numeric digits
            var m = Regex.Match(text, @"\bcreate\s+(\d+)\b|\bmake\s+(\d+)\b|\bcreate\s+(\d+)\s+(?:views|sheets)\b", RegexOptions.IgnoreCase);
            if (m.Success)
            {
                var val = m.Groups.Cast<Group>().Select(g => g.Value).FirstOrDefault(v => int.TryParse(v, out _));
                if (int.TryParse(val, out var n)) return n;
            }

            // try words one|two|three up to ten
            var wordNumbers = new Dictionary<string, int> { { "one", 1 }, { "two", 2 }, { "three", 3 }, { "four", 4 }, { "five", 5 }, { "six", 6 }, { "seven", 7 }, { "eight", 8 }, { "nine", 9 }, { "ten", 10 } };
            var wmatch = Regex.Match(text, @"\b(create|make)\s+(one|two|three|four|five|six|seven|eight|nine|ten)\b", RegexOptions.IgnoreCase);
            if (wmatch.Success)
            {
                var w = wmatch.Groups[2].Value.ToLower();
                if (wordNumbers.ContainsKey(w)) return wordNumbers[w];
            }

            return null;
        }

        // -------------------
        // Extract view type: floor plan, structural plan, ceiling plan, 3d
        // -------------------
        public string ExtractViewType(string text)
        {
            var lower = text?.ToLower() ?? string.Empty;
            if (Regex.IsMatch(lower, @"\b(structural\s*plan|structural)\b")) return "StructuralPlan";
            if (Regex.IsMatch(lower, @"\b(floor\s*plan|floorplan|floor)\b")) return "FloorPlan";
            if (Regex.IsMatch(lower, @"\b(ceiling\s*plan|ceiling|rcp)\b")) return "CeilingPlan";
            if (Regex.IsMatch(lower, @"\b(3d\s*view|three-?d|3d)\b")) return "ThreeD";
            return string.Empty;
        }

        // -------------------
        // Extract sheet type/subtype token if user mentions it (e.g., "in Softscape plan" => type "Softscape")
        // This is heuristic and project-specific — returns the token found after 'in' or 'under' near 'sheet' word.
        // -------------------
        public string ExtractSheetSubtype(string text)
        {
            if (string.IsNullOrWhiteSpace(text)) return string.Empty;
            var m = Regex.Match(text, @"\bsheet\b.*?(?:in|under|for)\s+([A-Za-z0-9\-\s]+?)(?:\s|$)", RegexOptions.IgnoreCase);
            if (m.Success) return m.Groups[1].Value.Trim();
            // fallback: 'in Softscape plan'
            var m2 = Regex.Match(text, @"(?:in|under)\s+([A-Za-z0-9\-\s]+?)\s+plan", RegexOptions.IgnoreCase);
            if (m2.Success) return m2.Groups[1].Value.Trim();
            return string.Empty;
        }

        // -------------------
        // Extract level single token (supports numbers and words)
        // Examples: "level 2", "on level 3", "on level G", "at level ground"
        // -------------------
        public string ExtractLevel(string text)
        {
            if (string.IsNullOrWhiteSpace(text)) return string.Empty;
            var match = Regex.Match(text, @"\blevel\s+([0-9]+|one|two|three|four|five|ground|g|basement|b\d+|\w+)\b", RegexOptions.IgnoreCase);
            return match.Success ? match.Groups[1].Value.Trim() : string.Empty;
        }

        // -------------------
        // Extract list of levels when user provides multiple like:
        // "create 3 floor plans on level 3,4,5" or "on levels 3, 4 and 5"
        // returns list in order.
        // -------------------
        public List<string> ExtractLevelsList(string text)
        {
            var levels = new List<string>();
            if (string.IsNullOrWhiteSpace(text)) return levels;

            // match sequences after 'level(s)' or 'on levels'
            var m = Regex.Match(text, @"(?:levels?|on\s+levels?|on\s+level)\s+([0-9a-zA-Z,\s\-and]+)", RegexOptions.IgnoreCase);
            if (m.Success)
            {
                var raw = m.Groups[1].Value;
                // split by comma or 'and'
                var parts = Regex.Split(raw, @"\s*(?:,|and|\s)\s*").Where(p => !string.IsNullOrWhiteSpace(p)).Select(p => p.Trim()).ToList();
                // keep only plausible tokens
                foreach (var p in parts)
                {
                    if (Regex.IsMatch(p, @"^[0-9]+$") || Regex.IsMatch(p, @"^\w+$")) levels.Add(p);
                }
            }
            else
            {
                // fallback: single level
                var single = ExtractLevel(text);
                if (!string.IsNullOrEmpty(single)) levels.Add(single);
            }
            return levels;
        }

        // -------------------
        // Extract export type
        // -------------------
        public ExportType? ExtractExportType(string text)
        {
            var lowerText = text?.ToLower() ?? string.Empty;
            if (lowerText.Contains("pdf")) return ExportType.PDF;
            if (lowerText.Contains("dwg")) return ExportType.DWG;
            if (lowerText.Contains("obj")) return ExportType.OBJ;
            if (lowerText.Contains("nwc")) return ExportType.NWC;
            return null;
        }

        // -------------------
        // For renames: more flexible extraction
        // Accepts:
        // - rename sheet A104 to A106-Shrubs Plan
        // - rename "Old Name" to "New Name"
        // - rename view OldPartial to NewName
        // -------------------
        public string ExtractOldName(string text)
        {
            if (string.IsNullOrWhiteSpace(text)) return string.Empty;

            // If quoted form
            var quoted = Regex.Match(text, @"rename\s+(?:view|sheet|schedule|legend)?\s*[""'](.+?)[""']", RegexOptions.IgnoreCase);
            if (quoted.Success) return quoted.Groups[1].Value.Trim();

            // If 'rename A104 to' or 'rename sheet A104 to'
            var m = Regex.Match(text, @"rename\s+(?:view|sheet|schedule|legend)?\s*([A-Za-z0-9\-\_]+(?:\s+[A-Za-z0-9\-\_]+)*)\s+(?:to|→)", RegexOptions.IgnoreCase);
            if (m.Success) return m.Groups[1].Value.Trim();

            // fallback: before arrow -> 'Old -> New' or 'Old to New'
            var arrow = Regex.Match(text, @"^(.+?)\s*(?:to|→)\s*[""']?.+?[""']?$", RegexOptions.IgnoreCase);
            if (arrow.Success) return arrow.Groups[1].Value.Trim();

            return string.Empty;
        }

        public string ExtractNewName(string text)
        {
            if (string.IsNullOrWhiteSpace(text)) return string.Empty;

            // If quoted new name
            var quoted = Regex.Match(text, @"(?:to|→)\s*[""'](.+?)[""']", RegexOptions.IgnoreCase);
            if (quoted.Success) return quoted.Groups[1].Value.Trim();

            // to NewName (unquoted)
            var m = Regex.Match(text, @"(?:to|→)\s*([A-Za-z0-9\-\_].+)$", RegexOptions.IgnoreCase);
            if (m.Success) return m.Groups[1].Value.Trim();

            // fallback: last two words
            var words = text.Trim().Split(' ');
            if (words.Length >= 2) return words[words.Length - 2] + " " + words[words.Length - 1];
            return words.LastOrDefault() ?? string.Empty;
        }

        // -------------------
        // Extract sheet number and title from a name like "A104-Tree Plan" or "A104 Tree Plan"
        // returns Tuple<number, title> where number may be null if not present.
        // -------------------
        public (string number, string title) ParseSheetNumberAndTitle(string text)
        {
            if (string.IsNullOrWhiteSpace(text)) return (string.Empty, string.Empty);

            // common pattern: A104-Title or A104 Title
            var m = Regex.Match(text.Trim(), @"^([A-Za-z0-9\-]+)[\s\-:]+(.+)$");
            if (m.Success) return (m.Groups[1].Value.Trim(), m.Groups[2].Value.Trim());

            // else no number
            return (string.Empty, text.Trim());
        }

        // -------------------
        // Duplicate options: with detailing, without detailing, as dependent
        // e.g. "duplicate Overall Plan with detailing and name it New"
        // -------------------
        public (string mode, string newName) ExtractDuplicateOptions(string text)
        {
            var mode = string.Empty;
            var lower = text?.ToLower() ?? string.Empty;
            if (lower.Contains("with detailing") || lower.Contains("with detail")) mode = "WithDetailing";
            if (lower.Contains("without detailing") || lower.Contains("no detailing")) mode = "WithoutDetailing";
            if (lower.Contains("as dependent") || lower.Contains("dependent")) mode = "AsDependent";

            // new name
            var name = ExtractNewName(text);
            if (string.IsNullOrEmpty(name))
            {
                // also check 'name it X' or 'and name it X'
                var m = Regex.Match(text, @"(?:name it|and name it|name)\s+[""']?(.+?)[""']?(?:\s|$)", RegexOptions.IgnoreCase);
                if (m.Success) name = m.Groups[1].Value.Trim();
            }

            return (mode, name);
        }

        // -------------------
        // Parameter change extraction: element name, param name, new value
        // Examples:
        // - change material of Wall 1 to Glass
        // - set Mark of Column A to 15
        // - change keynote of Door 1 to K-101
        // -------------------
        public (string elementName, string paramName, string newValue) ExtractParameterChange(string text)
        {
            var paramName = string.Empty;
            var lower = text?.ToLower() ?? string.Empty;

            if (lower.Contains("material") || lower.Contains("structural material")) paramName = "Material";
            else if (lower.Contains("mark")) paramName = "Mark";
            else if (Regex.IsMatch(lower, @"\bcomment(s)?\b")) paramName = "Comments";
            else if (lower.Contains("keynote")) paramName = "Keynote";
            else if (lower.Contains("name")) paramName = "Name";

            // element name: after "of" or "for" or before "to"
            var elMatch = Regex.Match(text, @"(?:of|for)\s+(""?.+?""?)\s+(?:to|=)", RegexOptions.IgnoreCase);
            string elementName = string.Empty;
            if (elMatch.Success) elementName = elMatch.Groups[1].Value.Trim(new[] { '"', '\'', ' ' });

            // new value after 'to' or 'set to'
            var valMatch = Regex.Match(text, @"(?:to|set to|=)\s*""?(.+?)""?(?:\s|$)", RegexOptions.IgnoreCase);
            string newValue = valMatch.Success ? valMatch.Groups[1].Value.Trim() : string.Empty;

            // fallback: more generic - last token
            if (string.IsNullOrEmpty(newValue))
            {
                var parts = text.Split(' ');
                if (parts.Length > 0) newValue = parts.Last().Trim(new[] { '.', ',', ' ' });
            }

            return (elementName, paramName, newValue);
        }

        // -------------------
        // Extract schedule category (e.g., Wall schedule, Door schedule)
        // -------------------
        public string ExtractCategory(string text)
        {
            var match = Regex.Match(text, @"\b(schedule|schedule named|create schedule|create a)\b.*?\b(wall|door|window|floor|furniture|room|lighting|plumbing|ceilings?)\b", RegexOptions.IgnoreCase);
            if (match.Success) return match.Groups[2].Value.Trim();
            // fallback: 'create schedule Doors' -> grab last word
            var simple = Regex.Match(text, @"create\s+schedule\s+(.+)$", RegexOptions.IgnoreCase);
            if (simple.Success) return simple.Groups[1].Value.Trim();
            return string.Empty;
        }

        // -------------------
        // Create level extraction: "create level 4 at 3000" or multiple "create level 3,4,5 at 3000,6000,9000 respectively"
        // returns pair lists: levelNumbers and elevations
        // -------------------
        public (List<string> levelNumbers, List<string> elevations) ExtractLevelsForCreate(string text)
        {
            var levels = new List<string>();
            var elevs = new List<string>();
            if (string.IsNullOrWhiteSpace(text)) return (levels, elevs);

            // capture numbers after 'create level' or 'create levels'
            var m = Regex.Match(text, @"create\s+levels?\s+([0-9a-zA-Z\-,\s]+?)(?:\s+at\s+([0-9a-zA-Z,\s\-]+))?$", RegexOptions.IgnoreCase);
            if (m.Success)
            {
                var rawLevels = m.Groups[1].Value;
                levels = Regex.Split(rawLevels, @"\s*,\s*").Select(s => s.Trim()).Where(s => s.Length > 0).ToList();

                if (m.Groups.Count >= 3 && m.Groups[2].Success)
                {
                    var rawElev = m.Groups[2].Value;
                    elevs = Regex.Split(rawElev, @"\s*,\s*").Select(s => s.Trim()).Where(s => s.Length > 0).ToList();
                }
            }
            else
            {
                // maybe 'create level 4 at 3000'
                var m2 = Regex.Match(text, @"create\s+level\s+([0-9a-zA-Z]+)\s+at\s+([0-9\.\-]+)", RegexOptions.IgnoreCase);
                if (m2.Success)
                {
                    levels.Add(m2.Groups[1].Value.Trim());
                    elevs.Add(m2.Groups[2].Value.Trim());
                }
            }

            return (levels, elevs);
        }

        // -------------------
        // Simple fallback extract value (for param or generic)
        // -------------------
        public string ExtractValue(string text)
        {
            var match = Regex.Match(text, @"to\s+""?(.+?)""?", RegexOptions.IgnoreCase);
            if (match.Success) return match.Groups[1].Value.Trim();

            var parts = (text ?? string.Empty).Split(' ');
            return parts.LastOrDefault() ?? string.Empty;
        }
        public string GetParameterName(string text)
        {
            if (string.IsNullOrWhiteSpace(text)) return string.Empty;

            var lower = text.ToLower();

            if (lower.Contains("material")) return "Material";
            if (lower.Contains("mark")) return "Mark";
            if (lower.Contains("comment")) return "Comments";
            if (lower.Contains("keynote")) return "Keynote";
            if (lower.Contains("name")) return "Name";

            return string.Empty;
        }
    }
}
