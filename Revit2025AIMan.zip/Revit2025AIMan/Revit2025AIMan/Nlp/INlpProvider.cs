﻿using Revit2025AIMan.Commands;
using Revit2025AIMan.Core;
using System.Collections.Generic;

namespace Revit2025AIMan.NLP
{
    public interface INlpProvider
    {
        Intent GetIntent(string text);

        // --- Names & counts ---
        string ExtractName(string text);
        List<string> ExtractNamesList(string text);
        int? ExtractCount(string text);

        // --- View/Sheet/Level ---
        string ExtractViewType(string text);
        string ExtractSheetSubtype(string text);
        string ExtractLevel(string text);
        List<string> ExtractLevelsList(string text);
        (List<string> levelNumbers, List<string> elevations) ExtractLevelsForCreate(string text);

        // --- Sheet naming ---
        (string number, string title) ParseSheetNumberAndTitle(string text);

        // --- Rename ---
        string ExtractOldName(string text);
        string ExtractNewName(string text);

        // --- Export ---
        ExportType? ExtractExportType(string text);

        // --- Parameters ---
        string GetParameterName(string text);
        (string elementName, string paramName, string newValue) ExtractParameterChange(string text);
        string ExtractValue(string text);

        // --- Duplicate ---
        (string mode, string newName) ExtractDuplicateOptions(string text);

        // --- Category (Schedules) ---
        string ExtractCategory(string text);
    }
}
