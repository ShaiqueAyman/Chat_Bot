﻿using System.Windows.Threading;
using System;

namespace Revit2025AIMan.Utils
{
    public static class UiThread
    {
        private static Dispatcher _dispatcher;
        public static void SetDispatcher(Dispatcher dispatcher) => _dispatcher = dispatcher;
        public static void Invoke(Action action)
        {
            if (_dispatcher != null && !_dispatcher.CheckAccess())
            {
                _dispatcher.Invoke(action);
            }
            else
            {
                action();
            }
        }
    }
}