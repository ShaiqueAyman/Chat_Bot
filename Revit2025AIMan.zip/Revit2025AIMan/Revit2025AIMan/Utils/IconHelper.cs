﻿// Placeholder for icon-related helpers
namespace Revit2025AIMan.Utils
{
    public class IconHelper
    {
    }
}