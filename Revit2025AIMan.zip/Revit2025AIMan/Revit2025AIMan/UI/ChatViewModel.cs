﻿using System.Collections.ObjectModel;
using System.Windows.Input;
using Autodesk.Revit.UI;
using Revit2025AIMan.Commands;
using Revit2025AIMan.Core;
using Revit2025AIMan.NLP;
using Revit2025AIMan.Utils;
using System.Windows.Threading;

namespace Revit2025AIMan.UI
{
    public class ChatViewModel : ViewModelBase
    {
        private string _userInput;
        public string UserInput
        {
            get => _userInput;
            set { _userInput = value; OnPropertyChanged(nameof(UserInput)); }
        }

        public ObservableCollection<ChatMessage> Messages { get; set; }
        public ICommand SendCommand { get; }
        public ICommand ShowSuggestionsCommand { get; }

        // ADDED: Suggestions property to hold suggestions list
        public ObservableCollection<string> Suggestions { get; set; }  // ADDED

        // ADDED: to control suggestion visibility
        private bool _showSuggestions = true;  // ADDED
        public bool ShowSuggestions          // ADDED
        {
            get => _showSuggestions;
            set
            {
                _showSuggestions = value;
                OnPropertyChanged(nameof(ShowSuggestions));
            }
        }

        private readonly ChatExternalEventHandler _eventHandler;
        private readonly ExternalEvent _externalEvent;

        public ChatViewModel()
        {
            Messages = new ObservableCollection<ChatMessage>();

            // ADDED: initialize Suggestions
            Suggestions = new ObservableCollection<string>();  // ADDED

            // This is the correct place to initialize UiThread
            UiThread.SetDispatcher(Dispatcher.CurrentDispatcher);

            var nlpProvider = new SimpleNlpProvider();
            var commandRouter = new CommandRouter(nlpProvider);
            _eventHandler = new ChatExternalEventHandler(commandRouter);
            _externalEvent = ExternalEvent.Create(_eventHandler);

            SendCommand = new RelayCommand(OnSend, () => !string.IsNullOrWhiteSpace(UserInput));
            ShowSuggestionsCommand = new RelayCommand(OnShowSuggestions);

            AddBotMessage("Hello, I'm A.I.Man. How can I assist you today?");
        }

        private void OnSend()
        {
            AddUserMessage(UserInput);
            _eventHandler.CurrentRequest = new ChatRequest(UserInput);
            _externalEvent.Raise();
            UserInput = string.Empty;

            ShowSuggestions = false;  // ADDED: hide suggestions when user sends a message
        }

        private void OnShowSuggestions()
        {
            Suggestions.Clear();
            Suggestions.Add("Create/Rename Views, Sheets, Schedules");
            Suggestions.Add("List properties of elements");
            Suggestions.Add("Export Sheets/DWG/PDF");
            Suggestions.Add("Change material/mark value");
            Suggestions.Add("Reload a Revit link");
            Suggestions.Add("Duplicate a view");

            ShowSuggestions = true;  // ADDED: show suggestions when help button clicked
        }

        public void AddBotMessage(string message) => UiThread.Invoke(() => Messages.Add(new ChatMessage(message, true)));
        public void AddUserMessage(string message) => UiThread.Invoke(() => Messages.Add(new ChatMessage(message, false)));
    }
}
