﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace Revit2025AIMan.UI
{
    public class BoolToBrushConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is bool isBotMessage)
            {
                return isBotMessage
                    ? (SolidColorBrush)(new BrushConverter().ConvertFrom("#ccc")) // Bot = Light Gray
                    : (SolidColorBrush)(new BrushConverter().ConvertFrom("#66ccee")); // User = Blue
            }

            return (SolidColorBrush)(new BrushConverter().ConvertFrom("#000")); // Default = Black
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
