﻿// This is a placeholder file for additional converters if needed.
namespace Revit2025AIMan.UI
{
    public class Converter
    {
    }
}