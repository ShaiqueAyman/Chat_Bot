﻿using System;
using System.Windows.Media.Imaging;

namespace Revit2025AIMan.UI
{
    public class ChatMessage
    {
        public string Message { get; set; }
        public bool IsBotMessage { get; set; }
        public BitmapImage IconSource { get; set; }

        public ChatMessage(string message, bool isBotMessage)
        {
            Message = message;
            IsBotMessage = isBotMessage;
            IconSource = isBotMessage ? GetBotIcon() : GetUserIcon();
        }

        private BitmapImage GetBotIcon()
        {
            // Path to your bot icon
            return new BitmapImage(new Uri("pack://application:,,,/Revit2025AIMan;component/Resources/Icons/A.I.Man.png"));
        }

        private BitmapImage GetUserIcon()
        {
            // Path to your user icon
            return new BitmapImage(new Uri("pack://application:,,,/Revit2025AIMan;component/Resources/Icons/User.png"));
        }
    }
}