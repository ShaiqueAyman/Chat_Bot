﻿using System.Windows.Controls;
using System.Windows.Input;

namespace Revit2025AIMan.UI
{
    public partial class ChatDockPane : UserControl
    {
        public ChatDockPane()
        {
            InitializeComponent();
        }

        private void InputTextBox_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                var viewModel = DataContext as ChatViewModel;
                if (viewModel != null && viewModel.SendCommand.CanExecute(null))
                {
                    viewModel.SendCommand.Execute(null);
                }
            }
        }
    }
}