﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Revit2025AIMan.Core;
using Revit2025AIMan.NLP;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Revit2025AIMan.Commands
{
    public class ExportCommands
    {
        private readonly INlpProvider _nlpProvider;
        public ExportCommands(INlpProvider nlpProvider) => _nlpProvider = nlpProvider;

        public void Export(UIDocument uiDoc, string rawText)
        {
            var doc = uiDoc.Document;
            var exportType = _nlpProvider.ExtractExportType(rawText);
            var nameToExport = _nlpProvider.ExtractName(rawText);

            if (string.IsNullOrEmpty(nameToExport) || exportType == null)
            {
                App.ChatViewModel.AddBotMessage("Please specify a name and export format (e.g., 'export sheet \"A101\" to pdf').");
                return;
            }

            var viewToExport = RevitServices.GetViewByName(doc, nameToExport);
            if (viewToExport == null)
            {
                App.ChatViewModel.AddBotMessage($"View or Sheet '{nameToExport}' not found.");
                return;
            }

            string exportPath = GetExportPath();
            if (string.IsNullOrEmpty(exportPath))
            {
                App.ChatViewModel.AddBotMessage("Export cancelled.");
                return;
            }

            Txn.Run(doc, "Export View/Sheet", t =>
            {
                var viewSet = new System.Collections.Generic.List<ElementId> { viewToExport.Id };

                switch (exportType)
                {
                    case ExportType.PDF:
                        // FIX: remove the "viewToExport.Name" string arg, use the overload that takes viewIds + options
                        doc.Export(exportPath, new List<ElementId> { viewToExport.Id }, new PDFExportOptions());
                        App.ChatViewModel.AddBotMessage($"Successfully exported '{viewToExport.Name}' to '{exportPath}' as PDF.");
                        break;

                    case ExportType.DWG:
                        // FIX: change from passing ViewSheet[] to passing viewIds + name + options
                        doc.Export(exportPath, viewToExport.Name, new List<ElementId> { viewToExport.Id }, new DWGExportOptions());
                        App.ChatViewModel.AddBotMessage($"Successfully exported '{viewToExport.Name}' to '{exportPath}' as DWG.");
                        break;

                    default:
                        App.ChatViewModel.AddBotMessage($"Export to {exportType} is not yet supported.");
                        break;
                }
            });
        }

        private string GetExportPath()
        {
            var dialog = new FolderBrowserDialog();
            return dialog.ShowDialog() == DialogResult.OK ? dialog.SelectedPath : null;
        }
    }
}