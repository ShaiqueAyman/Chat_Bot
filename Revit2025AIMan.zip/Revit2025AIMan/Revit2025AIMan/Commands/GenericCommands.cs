﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Revit2025AIMan.Core;
using Revit2025AIMan.NLP;
using System.Linq;

namespace Revit2025AIMan.Commands
{
    public class GenericCommands
    {
        private readonly INlpProvider _nlpProvider;
        private readonly ConversationManager _conversationManager;

        public GenericCommands(INlpProvider nlpProvider, ConversationManager conversationManager)
        {
            _nlpProvider = nlpProvider;
            _conversationManager = conversationManager;
        }

        public void ChangeElementParameter(UIDocument uiDoc, string rawText)
        {
            var doc = uiDoc.Document;
            var elementName = _nlpProvider.ExtractName(rawText);
            var paramName = _nlpProvider.GetParameterName(rawText);
            var newValue = _nlpProvider.ExtractValue(rawText);

            if (string.IsNullOrEmpty(elementName) || string.IsNullOrEmpty(paramName) || string.IsNullOrEmpty(newValue))
            {
                App.ChatViewModel.AddBotMessage("Please provide all details: `change [parameter]` of `[element]` to `[value]`.");
                return;
            }

            var element = RevitServices.GetElementByName(doc, elementName);
            if (element == null)
            {
                App.ChatViewModel.AddBotMessage($"Element '{elementName}' not found.");
                return;
            }

            Txn.Run(doc, "Change Parameter", t =>
            {
                var param = element.LookupParameter(paramName);
                if (param == null)
                {
                    App.ChatViewModel.AddBotMessage($"Parameter '{paramName}' not found on element '{element.Name}'.");
                    return;
                }
                param.Set(newValue);
                App.ChatViewModel.AddBotMessage($"Changed '{paramName}' of '{element.Name}' to '{newValue}'.");
            });
        }
    }
}