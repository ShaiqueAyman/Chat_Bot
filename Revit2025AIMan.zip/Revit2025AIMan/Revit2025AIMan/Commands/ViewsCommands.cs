﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Revit2025AIMan.Core;
using Revit2025AIMan.NLP;
using System;
using System.Linq;

namespace Revit2025AIMan.Commands
{
    public class ViewsCommands
    {
        private readonly INlpProvider _nlpProvider;
        private readonly ConversationManager _conversationManager;
        public ViewsCommands(INlpProvider nlpProvider, ConversationManager conversationManager)
        {
            _nlpProvider = nlpProvider;
            _conversationManager = conversationManager;
        }

        // New overload
        public void CreateView(UIDocument uiDoc, string viewName, string viewTypeStr, string levelToken)
        {
            var doc = uiDoc.Document;
            if (string.IsNullOrEmpty(viewTypeStr) || string.IsNullOrEmpty(viewName))
            {
                App.ChatViewModel.AddBotMessage("Please specify a view type and name.");
                return;
            }

            // Find view family type
            var viewFamilyType = new FilteredElementCollector(doc).OfClass(typeof(ViewFamilyType))
                .Cast<ViewFamilyType>()
                .FirstOrDefault(vft =>
                    vft.ViewFamily.ToString().Equals(viewTypeStr, StringComparison.OrdinalIgnoreCase) ||
                    viewTypeStr.Equals("ThreeD", StringComparison.OrdinalIgnoreCase) && vft.ViewFamily == ViewFamily.ThreeDimensional);

            if (viewFamilyType == null)
            {
                App.ChatViewModel.AddBotMessage($"Could not find a view family type for '{viewTypeStr}'.");
                return;
            }

            Txn.Run(doc, "Create View", t =>
            {
                if (viewFamilyType.ViewFamily == ViewFamily.FloorPlan || viewFamilyType.ViewFamily == ViewFamily.StructuralPlan)
                {
                    Level level = null;
                    if (!string.IsNullOrEmpty(levelToken))
                    {
                        // Try numeric match
                        level = new FilteredElementCollector(doc).OfClass(typeof(Level)).Cast<Level>()
                                .FirstOrDefault(l => l.Name.Equals(levelToken, StringComparison.OrdinalIgnoreCase)
                                                  || l.Name.EndsWith(levelToken, StringComparison.OrdinalIgnoreCase)
                                                  || (int.TryParse(levelToken, out var lvNum) && l.Name == levelToken));
                    }

                    // fallback to first level
                    if (level == null)
                        level = new FilteredElementCollector(doc).OfClass(typeof(Level)).Cast<Level>().FirstOrDefault();

                    if (level == null)
                    {
                        App.ChatViewModel.AddBotMessage("No levels found to create a plan view.");
                        t.RollBack();
                        return;
                    }

                    var newView = ViewPlan.Create(doc, viewFamilyType.Id, level.Id);
                    newView.Name = viewName;
                    App.ChatViewModel.AddBotMessage($"Created {viewFamilyType.ViewFamily} '{newView.Name}' on level '{level.Name}'.");
                }
                else
                {
                    App.ChatViewModel.AddBotMessage($"Creating {viewFamilyType.ViewFamily} views is not yet supported.");
                    t.RollBack();
                }
            });
        }


        public void DuplicateView(UIDocument uiDoc, string rawText)
        {
            var doc = uiDoc.Document;
            var viewName = _nlpProvider.ExtractName(rawText);
            if (string.IsNullOrEmpty(viewName))
            {
                App.ChatViewModel.AddBotMessage("Please provide the name of the view to duplicate.");
                return;
            }

            var viewToDuplicate = RevitServices.GetViewByName(doc, viewName);
            if (viewToDuplicate == null)
            {
                App.ChatViewModel.AddBotMessage($"View '{viewName}' not found.");
                return;
            }

            App.ChatViewModel.AddBotMessage("Do you want to duplicate **with detailing** or **without detailing**?");
            _conversationManager.CurrentState = CommandState.AwaitingDuplicateOption;
            _conversationManager.StoredData = viewToDuplicate;
        }

        public void RenameView(UIDocument uiDoc, string rawText)
        {
            var doc = uiDoc.Document;
            var oldName = _nlpProvider.ExtractOldName(rawText);
            var newName = _nlpProvider.ExtractNewName(rawText);

            if (string.IsNullOrEmpty(oldName) || string.IsNullOrEmpty(newName))
            {
                App.ChatViewModel.AddBotMessage("Please use the format: 'rename view \"Old Name\" to \"New Name\"'.");
                return;
            }

            var view = RevitServices.GetViewByName(doc, oldName);
            if (view == null)
            {
                App.ChatViewModel.AddBotMessage($"View '{oldName}' not found.");
                return;
            }

            Txn.Run(doc, "Rename View", t =>
            {
                view.Name = newName;
                App.ChatViewModel.AddBotMessage($"Successfully renamed view '{oldName}' to '{newName}'.");
            });
        }
    }
}