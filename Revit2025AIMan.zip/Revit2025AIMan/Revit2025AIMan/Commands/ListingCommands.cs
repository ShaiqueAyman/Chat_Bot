﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Revit2025AIMan.Core;
using Revit2025AIMan.NLP;
using System.Text;
using System.Linq;

namespace Revit2025AIMan.Commands
{
    public class ListingCommands
    {
        private readonly INlpProvider _nlpProvider;
        public ListingCommands(INlpProvider nlpProvider) => _nlpProvider = nlpProvider;

        public void ListElementProperties(UIDocument uiDoc, string rawText)
        {
            var doc = uiDoc.Document;
            var elementName = _nlpProvider.ExtractName(rawText);

            if (string.IsNullOrEmpty(elementName))
            {
                App.ChatViewModel.AddBotMessage("Please specify an element name (e.g., 'list properties of Wall').");
                return;
            }

            var elements = RevitServices.GetAllElementsByName(doc, elementName).ToList();
            if (!elements.Any())
            {
                App.ChatViewModel.AddBotMessage($"No elements with name '{elementName}' found.");
                return;
            }

            var element = elements.First(); // List properties of the first one found
            var properties = new StringBuilder();
            properties.AppendLine($"**Properties of {element.Name}** (ID: {element.Id}):");
            foreach (Parameter param in element.Parameters)
            {
                properties.AppendLine($"- **{param.Definition.Name}**: {param.AsValueString()}");
            }
            App.ChatViewModel.AddBotMessage(properties.ToString());
        }
    }
}