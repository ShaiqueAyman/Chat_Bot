﻿namespace Revit2025AIMan.Commands
{
    public enum Intent
    {
        Unknown,
        Create,
        Rename,
        ListProperties,
        Export,
        ChangeParameter,
        ReloadLink,
        DuplicateView
    }
}