﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Revit2025AIMan.Core;
using Revit2025AIMan.NLP;
using System.Linq;

namespace Revit2025AIMan.Commands
{
    public class SheetsCommands
    {
        private readonly INlpProvider _nlpProvider;
        public SheetsCommands(INlpProvider nlpProvider) => _nlpProvider = nlpProvider;

        public void CreateSheet(UIDocument uiDoc, string sheetTitle, string sheetNumber = "", string subtype = "")
        {
            var doc = uiDoc.Document;
            var titleBlockType = new FilteredElementCollector(doc).OfClass(typeof(FamilySymbol)).OfCategory(BuiltInCategory.OST_TitleBlocks)
                .Cast<FamilySymbol>().FirstOrDefault();

            if (titleBlockType == null)
            {
                App.ChatViewModel.AddBotMessage("No title block families are loaded in the project.");
                return;
            }

            Txn.Run(doc, "Create Sheet", t =>
            {
                var newSheet = ViewSheet.Create(doc, titleBlockType.Id);
                if (newSheet != null)
                {
                    // set number/title
                    if (!string.IsNullOrEmpty(sheetNumber))
                        newSheet.SheetNumber = sheetNumber;
                    newSheet.Name = sheetTitle;

                    // optional: set subtype by setting a sheet parameter if it exists (project-specific)
                    var subtypeParam = newSheet.LookupParameter("Discipline") ?? newSheet.LookupParameter("Sheet Type");
                    if (subtypeParam != null && !string.IsNullOrEmpty(subtype))
                    {
                        subtypeParam.Set(subtype);
                    }

                    App.ChatViewModel.AddBotMessage($"Successfully created sheet '{newSheet.SheetNumber} - {newSheet.Name}'.");
                }
            });
        }

        public void RenameSheet(UIDocument uiDoc, string rawText)
        {
            var doc = uiDoc.Document;
            var oldName = _nlpProvider.ExtractOldName(rawText);
            var newName = _nlpProvider.ExtractNewName(rawText);

            if (string.IsNullOrEmpty(oldName) || string.IsNullOrEmpty(newName))
            {
                App.ChatViewModel.AddBotMessage("Please specify old and new names (e.g., 'rename sheet \"Old Name\" to \"New Name\"').");
                return;
            }

            var sheet = RevitServices.GetViewByName(doc, oldName);
            if (sheet == null)
            {
                App.ChatViewModel.AddBotMessage($"Sheet '{oldName}' not found.");
                return;
            }

            Txn.Run(doc, "Rename Sheet", t =>
            {
                sheet.Name = newName;
                App.ChatViewModel.AddBotMessage($"Successfully renamed sheet '{oldName}' to '{newName}'.");
            });
        }

        // *** NEW METHOD ADDED HERE ***
        public void RenameSheet(UIDocument uiDoc, string oldName, string newName)
        {
            var doc = uiDoc.Document;

            // Find the sheet by oldName (using your existing helper method)
            var sheet = RevitServices.GetSheetByPartialNumberOrName(doc, oldName);

            if (sheet == null)
            {
                App.ChatViewModel.AddBotMessage($"Sheet '{oldName}' not found.");
                return;
            }

            // Run transaction to rename the sheet
            Txn.Run(doc, "Rename Sheet", t =>
            {
                sheet.Name = newName;
                App.ChatViewModel.AddBotMessage($"Successfully renamed sheet '{oldName}' to '{newName}'.");
            });
        }
    }
}
