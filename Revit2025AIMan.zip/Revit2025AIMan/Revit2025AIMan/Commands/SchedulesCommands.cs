﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Revit2025AIMan.Core;
using Revit2025AIMan.NLP;
using System.Linq;

namespace Revit2025AIMan.Commands
{
    public class SchedulesCommands
    {
        private readonly INlpProvider _nlpProvider;
        public SchedulesCommands(INlpProvider nlpProvider) => _nlpProvider = nlpProvider;

        public void CreateSchedule(UIDocument uiDoc, string rawText)
        {
            var doc = uiDoc.Document;
            var scheduleName = _nlpProvider.ExtractName(rawText);
            var categoryName = _nlpProvider.ExtractCategory(rawText);

            if (string.IsNullOrEmpty(scheduleName) || string.IsNullOrEmpty(categoryName))
            {
                App.ChatViewModel.AddBotMessage("Please specify a schedule name and category (e.g., 'create schedule Doors').");
                return;
            }

            var category = doc.Settings.Categories.Cast<Category>().FirstOrDefault(c => c.Name.Equals(categoryName, System.StringComparison.OrdinalIgnoreCase));
            if (category == null)
            {
                App.ChatViewModel.AddBotMessage($"Category '{categoryName}' not found.");
                return;
            }

            Txn.Run(doc, "Create Schedule", t =>
            {
                var newSchedule = ViewSchedule.CreateSchedule(doc, category.Id);
                newSchedule.Name = scheduleName;
                App.ChatViewModel.AddBotMessage($"Successfully created schedule '{newSchedule.Name}' for category '{category.Name}'.");
            });
        }

        public void RenameSchedule(UIDocument uiDoc, string rawText)
        {
            var doc = uiDoc.Document;
            var oldName = _nlpProvider.ExtractOldName(rawText);
            var newName = _nlpProvider.ExtractNewName(rawText);

            if (string.IsNullOrEmpty(oldName) || string.IsNullOrEmpty(newName))
            {
                App.ChatViewModel.AddBotMessage("Please specify old and new names (e.g., 'rename schedule \"Old\" to \"New\"').");
                return;
            }

            var schedule = new FilteredElementCollector(doc).OfClass(typeof(ViewSchedule)).Cast<ViewSchedule>().FirstOrDefault(s => s.Name.Equals(oldName, System.StringComparison.OrdinalIgnoreCase));
            if (schedule == null)
            {
                App.ChatViewModel.AddBotMessage($"Schedule '{oldName}' not found.");
                return;
            }

            Txn.Run(doc, "Rename Schedule", t =>
            {
                schedule.Name = newName;
                App.ChatViewModel.AddBotMessage($"Successfully renamed schedule '{oldName}' to '{newName}'.");
            });
        }
    }
}