﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Revit2025AIMan.Core;
using Revit2025AIMan.NLP;
using System.Linq;

namespace Revit2025AIMan.Commands
{
    public class LinksCommands
    {
        private readonly INlpProvider _nlpProvider;
        private readonly ConversationManager _conversationManager;

        public LinksCommands(INlpProvider nlpProvider, ConversationManager conversationManager)
        {
            _nlpProvider = nlpProvider;
            _conversationManager = conversationManager;
        }

        public void ReloadLink(UIDocument uiDoc, string rawText)
        {
            var doc = uiDoc.Document;
            var linkName = _nlpProvider.ExtractName(rawText);

            if (!string.IsNullOrEmpty(linkName))
            {
                var linkType = new FilteredElementCollector(doc).OfClass(typeof(RevitLinkType)).Cast<RevitLinkType>().FirstOrDefault(lt => lt.Name.Equals(linkName, System.StringComparison.OrdinalIgnoreCase));
                if (linkType != null)
                {
                    Txn.Run(doc, "Reload Link", t =>
                    {
                        linkType.Reload();
                        App.ChatViewModel.AddBotMessage($"Successfully reloaded link '{linkName}'.");
                    });
                }
                else
                {
                    App.ChatViewModel.AddBotMessage($"Link '{linkName}' not found. Please provide an exact name.");
                }
            }
            else
            {
                var links = new FilteredElementCollector(doc).OfClass(typeof(RevitLinkType)).Cast<RevitLinkType>().ToList();
                if (!links.Any())
                {
                    App.ChatViewModel.AddBotMessage("No Revit links found in the document.");
                    return;
                }

                App.ChatViewModel.AddBotMessage("Which link would you like to reload? Available links:");
                foreach (var link in links)
                {
                    App.ChatViewModel.AddBotMessage($"- {link.Name}");
                }
                _conversationManager.CurrentState = CommandState.AwaitingLinkReload;
                _conversationManager.StoredData = links;
            }
        }
    }
}