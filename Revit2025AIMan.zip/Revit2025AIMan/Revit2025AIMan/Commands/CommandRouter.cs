﻿using Autodesk.Revit.UI;
using Revit2025AIMan.Core;
using Revit2025AIMan.NLP;
using System;
using System.Linq;
using System.Text.RegularExpressions;

namespace Revit2025AIMan.Commands
{
    public class CommandRouter
    {
        private readonly INlpProvider _nlpProvider;
        private readonly ConversationManager _conversationManager;
        private readonly ExportCommands _exportCommands;
        private readonly FamiliesCommands _familiesCommands;
        private readonly GenericCommands _genericCommands;
        private readonly GroupsCommands _groupsCommands;
        private readonly LegendsCommands _legendsCommands;
        private readonly LinksCommands _linksCommands;
        private readonly ListingCommands _listingCommands;
        private readonly PluginCommands _pluginCommands;
        private readonly SchedulesCommands _schedulesCommands;
        private readonly SheetsCommands _sheetsCommands;
        private readonly ViewsCommands _viewsCommands;

        public CommandRouter(INlpProvider nlpProvider)
        {
            _nlpProvider = nlpProvider;
            _conversationManager = new ConversationManager();
            _exportCommands = new ExportCommands(_nlpProvider);
            _familiesCommands = new FamiliesCommands(_nlpProvider);
            _genericCommands = new GenericCommands(_nlpProvider, _conversationManager);
            _groupsCommands = new GroupsCommands(_nlpProvider);
            _legendsCommands = new LegendsCommands(_nlpProvider);
            _linksCommands = new LinksCommands(_nlpProvider, _conversationManager);
            _listingCommands = new ListingCommands(_nlpProvider);
            _pluginCommands = new PluginCommands(_nlpProvider);
            _schedulesCommands = new SchedulesCommands(_nlpProvider);
            _sheetsCommands = new SheetsCommands(_nlpProvider);
            _viewsCommands = new ViewsCommands(_nlpProvider, _conversationManager);
        }

        public void Route(UIDocument uiDoc, string rawText)
        {
            if (_conversationManager.CurrentState != CommandState.Idle)
            {
                _conversationManager.HandleResponse(uiDoc, rawText);
                return;
            }

            var intent = _nlpProvider.GetIntent(rawText);

            switch (intent)
            {
                case Intent.Create:
                    {
                        // handle create sheet(s) FIRST
                        if (Regex.IsMatch(rawText, @"\b(sheet|sheets)\b", RegexOptions.IgnoreCase))
                        {
                            var count = _nlpProvider.ExtractCount(rawText) ?? 1;
                            var names = _nlpProvider.ExtractNamesList(rawText);
                            // if user provided a sheet subtype (e.g., "in Softscape plan"), we pass it via ExtractSheetSubtype
                            var subtype = _nlpProvider.ExtractSheetSubtype(rawText);

                            if (!names.Any())
                            {
                                for (int i = 0; i < count; i++) names.Add($"New Sheet {i + 1}");
                            }

                            foreach (var n in names)
                            {
                                // Parse sheet number and title
                                var (number, title) = _nlpProvider.ParseSheetNumberAndTitle(n);
                                _sheetsCommands.CreateSheet(uiDoc, title, number, subtype);
                            }
                        }
                        // handle create view(s) AFTER sheets
                        else if (Regex.IsMatch(rawText, @"\b(view|plan|floor plan|structural plan|ceiling|3d)\b", RegexOptions.IgnoreCase))
                        {
                            // extract count, names list, levels list and view type
                            var count = _nlpProvider.ExtractCount(rawText) ?? 1;
                            var names = _nlpProvider.ExtractNamesList(rawText);
                            var levels = _nlpProvider.ExtractLevelsList(rawText);
                            var viewType = _nlpProvider.ExtractViewType(rawText);

                            // if names not provided, generate placeholder names
                            if (!names.Any())
                            {
                                for (int i = 0; i < count; i++) names.Add($"New {viewType} {i + 1}");
                            }

                            // Ensure lists line up (respectively): if levels given equal to count, pair them; else use first level or default
                            for (int i = 0; i < names.Count; i++)
                            {
                                var name = names[i];
                                var level = levels.ElementAtOrDefault(i) ?? levels.FirstOrDefault() ?? string.Empty;

                                // call views command - modify ViewsCommands.CreateView signature to accept level as optional arg
                                _viewsCommands.CreateView(uiDoc, name, viewType, level);
                            }
                        }
                        // handle schedule creation
                        else if (Regex.IsMatch(rawText, @"\bschedule\b", RegexOptions.IgnoreCase))
                        {
                            // SchedulesCommands.CreateSchedule already expects a schedule name & category via NLP — make sure ExtractCategory & ExtractName return values
                            _schedulesCommands.CreateSchedule(uiDoc, rawText);
                        }
                        // handle level creation (create level ...)
                        else if (Regex.IsMatch(rawText, @"\blevel\b", RegexOptions.IgnoreCase) && Regex.IsMatch(rawText, @"\bcreate\b", RegexOptions.IgnoreCase))
                        {
                            var (levelNumbers, elevations) = _nlpProvider.ExtractLevelsForCreate(rawText);
                            // implement a small helper to create levels in bulk in a new method (or add to ViewsCommands/SheetsCommands)
                            foreach (var idx in Enumerable.Range(0, Math.Max(levelNumbers.Count, 1)))
                            {
                                var lvlName = levelNumbers.ElementAtOrDefault(idx) ?? $"Level_{idx + 1}";
                                var elev = elevations.ElementAtOrDefault(idx) ?? elevations.FirstOrDefault() ?? string.Empty;
                                // call a new helper (you can place in RevitServices or a LevelsCommands) 
                                RevitServices.CreateLevel(uiDoc.Document, lvlName, elev);
                                App.ChatViewModel.AddBotMessage($"Created level '{lvlName}' at elevation {elev}.");
                            }
                        }
                    }
                    break;

                case Intent.Rename:
                    {
                        // flexible renaming:
                        var oldNameToken = _nlpProvider.ExtractOldName(rawText);
                        var newName = _nlpProvider.ExtractNewName(rawText);

                        if (string.IsNullOrEmpty(oldNameToken) || string.IsNullOrEmpty(newName))
                        {
                            App.ChatViewModel.AddBotMessage("Please specify old and new names (e.g., 'rename A104 to A106-Shrubs Plan').");
                            return;
                        }

                        // Try to find sheet by sheet number token (e.g., A104) first:
                        if (Regex.IsMatch(rawText, @"\b(sheet|sheets)\b", RegexOptions.IgnoreCase))
                        {
                            // try exact first
                            var sheet = RevitServices.GetSheetByPartialNumberOrName(uiDoc.Document, oldNameToken);
                            if (sheet != null)
                            {
                                _sheetsCommands.RenameSheet(uiDoc, sheet.Name, newName);
                                return;
                            }
                        }

                        // For views: support partial match of name
                        if (Regex.IsMatch(rawText, @"\b(view|views)\b", RegexOptions.IgnoreCase))
                        {
                            var view = RevitServices.GetViewByPartialName(uiDoc.Document, oldNameToken);
                            if (view != null)
                            {
                                _viewsCommands.RenameView(uiDoc, $"rename view \"{view.Name}\" to \"{newName}\"");
                                return;
                            }
                        }

                        // fallback: try schedule/legend rename direct
                        _sheetsCommands.RenameSheet(uiDoc, rawText);
                        _viewsCommands.RenameView(uiDoc, rawText);
                        _schedulesCommands.RenameSchedule(uiDoc, rawText);
                        _legendsCommands.RenameLegend(uiDoc, rawText);
                    }
                    break;

                case Intent.ListProperties:
                    _listingCommands.ListElementProperties(uiDoc, rawText);
                    break;

                case Intent.Export:
                    _exportCommands.Export(uiDoc, rawText);
                    break;

                case Intent.ChangeParameter:
                    {
                        // change material or other param
                        var (elementName, paramName, newValue) = _nlpProvider.ExtractParameterChange(rawText);
                        if (string.IsNullOrEmpty(elementName) || string.IsNullOrEmpty(paramName) || string.IsNullOrEmpty(newValue))
                        {
                            App.ChatViewModel.AddBotMessage("Please provide element name, parameter and value. e.g., 'change material of Wall 1 to Glass'.");
                            return;
                        }
                        _genericCommands.ChangeElementParameter(uiDoc, rawText); // existing method expects rawText & will call NLP again; kept for compatibility
                    }
                    break;

                case Intent.ReloadLink:
                    _linksCommands.ReloadLink(uiDoc, rawText);
                    break;

                case Intent.DuplicateView:
                    {
                        // duplicate view with options
                        var names = _nlpProvider.ExtractNamesList(rawText);
                        var (mode, dupeName) = _nlpProvider.ExtractDuplicateOptions(rawText);
                        // if name not provided, use names[0] as target, prompt user if missing
                        var targetName = _nlpProvider.ExtractName(rawText);
                        if (string.IsNullOrEmpty(targetName)) targetName = names.FirstOrDefault() ?? string.Empty;
                        if (string.IsNullOrEmpty(targetName))
                        {
                            App.ChatViewModel.AddBotMessage("Please specify the view to duplicate.");
                            return;
                        }

                        // route to ViewsCommands.DuplicateView which already sets conversation state to await detailing
                        _viewsCommands.DuplicateView(uiDoc, $"duplicate {targetName} {mode} to {dupeName}");
                    }
                    break;

                default:
                    App.ChatViewModel.AddBotMessage("I didn't understand that command. Try: create view/sheet, rename X to Y, duplicate view, create schedule, change material, or list properties.");
                    break;
            }
        }
    }
}