﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Revit2025AIMan.Core;
using Revit2025AIMan.NLP;

namespace Revit2025AIMan.Commands
{
    public class PluginCommands
    {
        private readonly INlpProvider _nlpProvider;
        public PluginCommands(INlpProvider nlpProvider) => _nlpProvider = nlpProvider;

        public void RunPlugin(UIDocument uiDoc, string rawText)
        {
            // Note: Executing other plugins is complex and requires their command ID.
            // This is a conceptual implementation.
            App.ChatViewModel.AddBotMessage("Running other plugins is not yet implemented.");
        }
    }
}