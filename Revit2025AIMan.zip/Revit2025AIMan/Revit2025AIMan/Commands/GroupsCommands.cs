﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Revit2025AIMan.Core;
using Revit2025AIMan.NLP;
using System.Linq;

namespace Revit2025AIMan.Commands
{
    public class GroupsCommands
    {
        private readonly INlpProvider _nlpProvider;
        public GroupsCommands(INlpProvider nlpProvider) => _nlpProvider = nlpProvider;

        public void CreateGroup(UIDocument uiDoc, string rawText)
        {
            var doc = uiDoc.Document;
            var groupName = _nlpProvider.ExtractName(rawText);

            if (string.IsNullOrEmpty(groupName))
            {
                App.ChatViewModel.AddBotMessage("Please provide a name for the group (e.g., 'create group My Group').");
                return;
            }

            var selectedIds = uiDoc.Selection.GetElementIds();
            if (selectedIds.Count == 0)
            {
                App.ChatViewModel.AddBotMessage("Please select elements to group and try again.");
                return;
            }

            Txn.Run(doc, "Create Group", t =>
            {
                var elementsToGroup = selectedIds.ToList(); // already ElementIds
                var group = doc.Create.NewGroup(elementsToGroup);
                if (group != null)
                {
                    group.GroupType.Name = groupName;
                    App.ChatViewModel.AddBotMessage($"Successfully created group '{groupName}'.");
                }
            });
        }
    }
}