﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Revit2025AIMan.Core;
using Revit2025AIMan.NLP;
using System.Windows.Forms;

namespace Revit2025AIMan.Commands
{
    public class FamiliesCommands
    {
        private readonly INlpProvider _nlpProvider;
        public FamiliesCommands(INlpProvider nlpProvider) => _nlpProvider = nlpProvider;

        public void LoadFamily(UIDocument uiDoc, string rawText)
        {
            var doc = uiDoc.Document;
            var familyName = _nlpProvider.ExtractName(rawText);

            App.ChatViewModel.AddBotMessage("Please select the family file to load.");
            var dialog = new OpenFileDialog
            {
                Filter = "Revit Family Files (*.rfa)|*.rfa",
                Title = "Select a Family File"
            };

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                Txn.Run(doc, "Load Family", t =>
                {
                    if (doc.LoadFamily(dialog.FileName))
                    {
                        App.ChatViewModel.AddBotMessage($"Successfully loaded family from: {dialog.FileName}");
                    }
                    else
                    {
                        App.ChatViewModel.AddBotMessage("Failed to load the family.");
                        t.RollBack();
                    }
                });
            }
        }
    }
}