﻿using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Revit2025AIMan.Core;
using Revit2025AIMan.NLP;
using System.Linq;

namespace Revit2025AIMan.Commands
{
    public class LegendsCommands
    {
        private readonly INlpProvider _nlpProvider;
        public LegendsCommands(INlpProvider nlpProvider) => _nlpProvider = nlpProvider;

        public void CreateLegend(UIDocument uiDoc, string rawText)
        {
            var doc = uiDoc.Document;
            var legendName = _nlpProvider.ExtractName(rawText);

            if (string.IsNullOrEmpty(legendName))
            {
                App.ChatViewModel.AddBotMessage("Please provide a name for the legend.");
                return;
            }

            Txn.Run(doc, "Create Legend", t =>
            {
                var viewFamilyTypeId = new FilteredElementCollector(doc)
                .OfClass(typeof(ViewFamilyType))
                .Cast<ViewFamilyType>()
                .FirstOrDefault(vft => vft.ViewFamily == ViewFamily.Legend)?.Id;

                if (viewFamilyTypeId == null)
                {
                    App.ChatViewModel.AddBotMessage("No Legend ViewFamilyType found in this project.");
                    return;
                }

                var newLegend = ViewDrafting.Create(doc, viewFamilyTypeId);
                if (newLegend != null)
                {
                    newLegend.Name = legendName;
                    App.ChatViewModel.AddBotMessage($"Successfully created legend view '{newLegend.Name}'.");
                }
            });
        }

        public void RenameLegend(UIDocument uiDoc, string rawText)
        {
            var doc = uiDoc.Document;
            var oldName = _nlpProvider.ExtractOldName(rawText);
            var newName = _nlpProvider.ExtractNewName(rawText);

            if (string.IsNullOrEmpty(oldName) || string.IsNullOrEmpty(newName))
            {
                App.ChatViewModel.AddBotMessage("Please specify old and new names (e.g., 'rename legend \"Old\" to \"New\"').");
                return;
            }

            var legend = RevitServices.GetViewByName(doc, oldName);
            if (legend == null)
            {
                App.ChatViewModel.AddBotMessage($"Legend view '{oldName}' not found.");
                return;
            }

            Txn.Run(doc, "Rename Legend", t =>
            {
                legend.Name = newName;
                App.ChatViewModel.AddBotMessage($"Successfully renamed legend view '{oldName}' to '{newName}'.");
            });
        }
    }
}