using Autodesk.Revit.UI;
using System;
using Revit2025AIMan.Commands;
using Revit2025AIMan.Core;

namespace Revit2025AIMan.Core
{
    public class ChatExternalEventHandler : IExternalEventHandler
    {
        private readonly CommandRouter _commandRouter;
        public ChatRequest CurrentRequest { get; set; }

        public ChatExternalEventHandler(CommandRouter commandRouter)
        {
            _commandRouter = commandRouter;
        }

        public void Execute(UIApplication app)
        {
            if (CurrentRequest == null) return;
            try
            {
                var uiDoc = app.ActiveUIDocument;
                if (uiDoc == null)
                {
                    App.ChatViewModel.AddBotMessage("Please open a Revit document to use this command.");
                    return;
                }
                _commandRouter.Route(uiDoc, CurrentRequest.UserInput);
            }
            catch (Exception ex)
            {
                App.ChatViewModel.AddBotMessage($"An error occurred: {ex.Message}");
            }
            finally
            {
                CurrentRequest = null;
            }
        }

        public string GetName() => "ChatExternalEventHandler";
    }
}