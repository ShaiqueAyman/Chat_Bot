﻿using Autodesk.Revit.Attributes;
using Autodesk.Revit.UI;
using System;

namespace Revit2025AIMan.Core
{
    [Transaction(TransactionMode.Manual)]
    public class ShowPaneCommand : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, Autodesk.Revit.DB.ElementSet elements)
        {
            var uiApp = commandData.Application;
            var paneId = new DockablePaneId(new Guid("D345B0A2-E8B0-4A93-8C9B-9F2B889E391A"));
            DockablePane dockablePane = uiApp.GetDockablePane(paneId);
            dockablePane.Show();
            return Result.Succeeded;
        }
    }
}