﻿using Autodesk.Revit.UI;
using Revit2025AIMan.Commands;

namespace Revit2025AIMan.Core
{
    // A new file to handle multi-step conversations.
    public class ConversationManager
    {
        public CommandState CurrentState { get; set; } = CommandState.Idle;
        public object StoredData { get; set; }

        public void HandleResponse(UIDocument uiDoc, string userInput)
        {
            // This is where you would handle the follow-up questions
            // For example, if the state is awaiting a duplicate option
            if (CurrentState == CommandState.AwaitingDuplicateOption)
            {
                if (userInput.ToLower().Contains("detailing"))
                {
                    // Logic for duplicating with detailing
                    CurrentState = CommandState.Idle;
                }
                else
                {
                    // Logic for duplicating without detailing
                    CurrentState = CommandState.Idle;
                }
            }
            // Add other states here
        }
    }

    public enum CommandState
    {
        Idle,
        AwaitingDuplicateOption,
        AwaitingParameterValue,
        AwaitingLinkReload
    }
}