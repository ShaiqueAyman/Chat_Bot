﻿using Autodesk.Revit.UI;
using System;
using System.IO;
using System.Windows.Media.Imaging;
using Revit2025AIMan.Utils;

namespace Revit2025AIMan.Core
{
    public class App : IExternalApplication
    {
        public static App ThisApp { get; private set; }
        public static UI.ChatViewModel ChatViewModel { get; private set; }

        public Result OnStartup(UIControlledApplication application)
        {
            ThisApp = this;
            ChatViewModel = new UI.ChatViewModel();
            var paneId = new DockablePaneId(new Guid("D345B0A2-E8B0-4A93-8C9B-9F2B889E391A"));
            application.RegisterDockablePane(paneId, "A.I.Man", new ChatDockPaneProvider(ChatViewModel));

            string assemblyPath = typeof(App).Assembly.Location;
            string tabName = "A.I.Man";
            try { application.CreateRibbonTab(tabName); } catch { }
            var panel = application.CreateRibbonPanel(tabName, "Chat-Bot");

            var showButton = new PushButtonData("A.I.Man", "A.I.Man", assemblyPath, "Revit2025AIMan.Core.ShowPaneCommand");

            string iconPath = Path.Combine(Path.GetDirectoryName(assemblyPath), "Resources", "Icons", "A.I.Man32.png");
            if (File.Exists(iconPath))
            {
                var iconUri = new Uri(iconPath, UriKind.Absolute);
                var bitmap = new BitmapImage(iconUri);

                showButton.LargeImage = bitmap;
                showButton.Image = bitmap;
            }

            panel.AddItem(showButton);

            return Result.Succeeded;
        }

        public Result OnShutdown(UIControlledApplication application)
        {
            return Result.Succeeded;
        }
    }
}