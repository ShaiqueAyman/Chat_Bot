﻿namespace Revit2025AIMan.Core
{
    public enum ExportType
    {
        PDF,
        DWG,
        OBJ,
        NWC
    }
}
