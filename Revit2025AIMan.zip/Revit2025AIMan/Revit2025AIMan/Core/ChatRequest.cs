﻿namespace Revit2025AIMan.Core
{
    public class ChatRequest
    {
        public string UserInput { get; }
        public ChatRequest(string userInput)
        {
            UserInput = userInput;
        }
    }
}