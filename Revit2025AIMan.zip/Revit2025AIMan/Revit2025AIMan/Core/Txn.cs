﻿using Autodesk.Revit.DB;
using System;

namespace Revit2025AIMan.Core
{
    public static class Txn
    {
        public static void Run(Document doc, string name, Action<Transaction> action)
        {
            using (var t = new Transaction(doc, name))
            {
                t.Start();
                try
                {
                    action(t);
                    t.Commit();
                }
                catch (Exception ex)
                {
                    App.ChatViewModel.AddBotMessage($"Transaction failed: {ex.Message}");
                    if (t.GetStatus() == TransactionStatus.Started)
                    {
                        t.RollBack();
                    }
                }
            }
        }
    }
}