﻿using Autodesk.Revit.UI;

namespace Revit2025AIMan.Core
{
    public class ChatDockPaneProvider : IDockablePaneProvider
    {
        private readonly UI.ChatViewModel _viewModel;

        public ChatDockPaneProvider(UI.ChatViewModel viewModel)
        {
            _viewModel = viewModel;
        }

        public void SetupDockablePane(DockablePaneProviderData data)
        {
            var chatPane = new UI.ChatDockPane();
            chatPane.DataContext = _viewModel;
            data.FrameworkElement = chatPane;
            data.InitialState.DockPosition = DockPosition.Right;
        }
    }
}