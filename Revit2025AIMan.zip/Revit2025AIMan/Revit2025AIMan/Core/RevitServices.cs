﻿using Autodesk.Revit.DB;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Revit2025AIMan.Core
{
    public static class RevitServices
    {
        // --- Generic search with partial matching ---
        private static bool Matches(string source, string target)
        {
            if (string.IsNullOrWhiteSpace(source) || string.IsNullOrWhiteSpace(target))
                return false;

            // Case-insensitive and allows partial match
            return source.IndexOf(target, System.StringComparison.OrdinalIgnoreCase) >= 0;
        }

        public static Element GetElementByName(Document doc, string name)
        {
            return new FilteredElementCollector(doc)
                .WhereElementIsNotElementType()
                .FirstOrDefault(e => Matches(e.Name, name));
        }

        public static IEnumerable<Element> GetAllElementsByName(Document doc, string name)
        {
            return new FilteredElementCollector(doc)
                .WhereElementIsNotElementType()
                .Where(e => Matches(e.Name, name));
        }

        public static View GetViewByName(Document doc, string name)
        {
            return new FilteredElementCollector(doc)
                .OfClass(typeof(View))
                .Cast<View>()
                .FirstOrDefault(v => Matches(v.Name, name));
        }

        public static ViewSheet GetSheetByNumberOrName(Document doc, string input)
        {
            return new FilteredElementCollector(doc)
                .OfClass(typeof(ViewSheet))
                .Cast<ViewSheet>()
                .FirstOrDefault(s =>
                    Matches(s.Name, input) ||
                    Matches(s.SheetNumber, input));
        }

        public static FamilySymbol GetFamilySymbolByName(Document doc, string name)
        {
            return new FilteredElementCollector(doc)
                .OfClass(typeof(FamilySymbol))
                .Cast<FamilySymbol>()
                .FirstOrDefault(s => Matches(s.Name, name));
        }

        // ============================
        // === ADDED METHODS BELOW ===
        // ============================

        public static View GetViewByPartialName(Document doc, string partialName)
        {
            return new FilteredElementCollector(doc)
                .OfClass(typeof(View))
                .Cast<View>()
                .Where(v => !v.IsTemplate && Matches(v.Name, partialName))
                .FirstOrDefault();
        }

        public static ViewSheet GetSheetByPartialNumberOrName(Document doc, string token)
        {
            return new FilteredElementCollector(doc)
                .OfClass(typeof(ViewSheet))
                .Cast<ViewSheet>()
                .Where(s => Matches(s.SheetNumber, token) || Matches(s.Name, token))
                .FirstOrDefault();
        }

        public static void CreateLevel(Document doc, string name, string elevationStr)
        {
            if (!double.TryParse(elevationStr, out double elevation))
                elevation = 0;

            using (Transaction tx = new Transaction(doc, $"Create Level '{name}'"))
            {
                tx.Start();

                Level level = Level.Create(doc, elevation);
                level.Name = name;

                tx.Commit();
            }
        }
    }
}
